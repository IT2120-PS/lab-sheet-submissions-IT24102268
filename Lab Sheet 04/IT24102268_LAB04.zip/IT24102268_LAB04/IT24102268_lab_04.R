#1
setwd('C:\\Users\\it24102268\\Desktop\\IT24102268LAB04')
branch_data <-read.table("Exercise.txt",header = TRUE,sep =",")
fix (branch_data)
#2
attach(branch_data)
for(col in names(branch_data)){
  print(paste(col,":",class(branch_data[[col]])))
}
#3
boxplot(branch_data$Sales_X1,Main="Sales",outline =TRUE,outpch = 8,horizontal = TRUE,xlab="Sales")
#4
summary(Advertising_X2)
IQR(Advertising_X2)
#5
get.outliers<- function(x){
  q1<-quantile(x)[2]
  q3<-quantile(x)[4]
  iqr<-q3-q1
  lb<-q1-1.5*iqr
  ub<-q3+1.5*iqr
  
  print(paste("Upper Bound =",ub))
  print(paste("Lower Bound =",lb))
  print(paste("Outliers",paste(sort(x[x<lb |x >ub]),collapse = ",")))
}
get.outliers(Years_X3)